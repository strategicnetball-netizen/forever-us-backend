import express from 'express';
import { prisma } from '../index.js';
import { authenticate } from '../middleware/auth.js';
const router = express.Router();
// Get recent activity (matches and likes)
router.get('/', authenticate, async (req, res, next) => {
    try {
        const user = await prisma.user.findUnique({
            where: { id: req.userId }
        });
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        // Get recent matches (last 7 days)
        const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        const matches = await prisma.match.findMany({
            where: {
                OR: [
                    { userId: req.userId, createdAt: { gte: sevenDaysAgo } },
                    { matchedWithId: req.userId, createdAt: { gte: sevenDaysAgo } }
                ]
            },
            include: {
                user: { select: { id: true, name: true, age: true, avatar: true } },
                matchedWith: { select: { id: true, name: true, age: true, avatar: true } }
            },
            orderBy: { createdAt: 'desc' },
            take: 5
        });
        // Get recent likes (last 7 days)
        const likes = await prisma.like.findMany({
            where: {
                likedId: req.userId,
                createdAt: { gte: sevenDaysAgo }
            },
            include: {
                liker: { select: { id: true, name: true, age: true, avatar: true } }
            },
            orderBy: { createdAt: 'desc' },
            take: 5
        });
        // Format activities
        const activities = [];
        matches.forEach(match => {
            const otherUser = match.userId === req.userId ? match.matchedWith : match.user;
            activities.push({
                type: 'match',
                name: otherUser.name,
                age: otherUser.age,
                avatar: otherUser.avatar,
                timeAgo: getTimeAgo(match.createdAt),
                timestamp: match.createdAt
            });
        });
        likes.forEach(like => {
            activities.push({
                type: 'like',
                name: like.liker.name,
                age: like.liker.age,
                avatar: like.liker.avatar,
                timeAgo: getTimeAgo(like.createdAt),
                timestamp: like.createdAt
            });
        });
        // Sort by timestamp descending and take top 10
        activities.sort((a, b) => b.timestamp - a.timestamp);
        const result = activities.slice(0, 10).map(({ timestamp, ...rest }) => rest);
        res.json(result);
    }
    catch (err) {
        next(err);
    }
});
function getTimeAgo(date) {
    const now = new Date();
    const seconds = Math.floor((now - date) / 1000);
    if (seconds < 60)
        return 'just now';
    if (seconds < 3600)
        return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400)
        return `${Math.floor(seconds / 3600)}h ago`;
    if (seconds < 604800)
        return `${Math.floor(seconds / 86400)}d ago`;
    return date.toLocaleDateString();
}
export default router;
