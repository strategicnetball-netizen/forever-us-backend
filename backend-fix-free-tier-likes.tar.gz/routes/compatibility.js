import express from 'express';
import { prisma } from '../index.js';
import { authenticate } from '../middleware/auth.js';
const router = express.Router();
// Helper function to normalize answers for comparison
const normalizeAnswer = (answer) => {
    if (Array.isArray(answer)) {
        return answer.map(a => String(a).toLowerCase().trim()).sort().join('|');
    }
    return String(answer).toLowerCase().trim();
};
// Calculate similarity score between two answers (0-100)
const calculateSimilarity = (answer1, answer2) => {
    // If either answer is missing, return 0
    if (!answer1 || !answer2)
        return 0;
    const norm1 = normalizeAnswer(answer1);
    const norm2 = normalizeAnswer(answer2);
    // Exact match
    if (norm1 === norm2)
        return 100;
    // Partial match - one contains the other
    if (norm1.includes(norm2) || norm2.includes(norm1))
        return 70;
    // Check for common words (at least 50% overlap)
    const words1 = norm1.split(/\s+/).filter(w => w.length > 2);
    const words2 = norm2.split(/\s+/).filter(w => w.length > 2);
    if (words1.length > 0 && words2.length > 0) {
        const commonWords = words1.filter(w => words2.includes(w));
        const overlapRatio = commonWords.length / Math.max(words1.length, words2.length);
        if (overlapRatio >= 0.5)
            return 60;
        if (overlapRatio >= 0.25)
            return 40;
    }
    // Check for semantic similarity - opposite answers get some credit
    // (e.g., "yes" and "no" are related, just opposite)
    const opposites = [
        ['yes', 'no'],
        ['active', 'relaxed'],
        ['spontaneous', 'planned'],
        ['extrovert', 'introvert'],
        ['serious', 'casual'],
        ['ambitious', 'creative'],
        ['trust', 'loyalty'],
        ['honesty', 'loyalty']
    ];
    for (const [opt1, opt2] of opposites) {
        if ((norm1.includes(opt1) && norm2.includes(opt2)) ||
            (norm1.includes(opt2) && norm2.includes(opt1))) {
            return 30; // Opposite answers get 30% - they're related but different
        }
    }
    // No match
    return 0;
};
// Extract shared interests from questionnaire answers
const extractSharedInterests = (user1Int, user2Int) => {
    if (!user1Int || !user2Int)
        return [];
    const interests = [];
    for (let i = 1; i <= 10; i++) {
        const q = `id${i}`;
        if (user1Int[q] && user2Int[q]) {
            const sim = calculateSimilarity(user1Int[q], user2Int[q]);
            if (sim >= 70) {
                const interest = String(user1Int[q]).toLowerCase().trim();
                if (interest && !interests.includes(interest)) {
                    interests.push(interest);
                }
            }
        }
    }
    return interests.slice(0, 3);
};
// Extract shared values from questionnaire answers
const extractSharedValues = (user1Q, user2Q) => {
    const values = [];
    if (!user1Q || !user2Q)
        return values;
    // Check key value questions from profile questionnaire
    const valueQuestions = [
        { key: 'q9', label: 'Kids' },
        { key: 'q10', label: 'Religion' },
        { key: 'q11', label: 'Politics' },
        { key: 'q14', label: 'Spirituality' }
    ];
    valueQuestions.forEach(({ key, label }) => {
        if (user1Q[key] && user2Q[key]) {
            const sim = calculateSimilarity(user1Q[key], user2Q[key]);
            if (sim >= 70) {
                values.push(`Shared ${label}`);
            }
        }
    });
    return values.slice(0, 2);
};
// Calculate compatibility score using all questionnaires
const calculateCompatibility = (user1Data, user2Data) => {
    if (!user1Data || !user2Data) {
        return { overallScore: 0, breakdown: {}, summary: 'Unable to calculate compatibility' };
    }
    let scores = {
        profileValues: 0,
        profileLifestyle: 0,
        profileGoals: 0,
        personality: 0,
        relationshipGoals: 0,
        lifestyle: 0,
        valuesBeliefs: 0,
        interestsHobbies: 0,
        musicPersonality: 0,
        lifestylePreferences: 0,
        dealbreakers: 100
    };
    let activeScores = 0; // Track how many score categories have data
    // ===== PROFILE QUESTIONNAIRE (20 questions) =====
    if (user1Data.profile && user2Data.profile && typeof user1Data.profile === 'object' && typeof user2Data.profile === 'object' && Object.keys(user1Data.profile).length > 0 && Object.keys(user2Data.profile).length > 0) {
        const p1 = user1Data.profile;
        const p2 = user2Data.profile;
        activeScores += 3; // Count profile values, lifestyle, and goals
        // Values Alignment (q9=kids, q10=religion, q11=politics, q14=spirituality)
        const profileValuesQuestions = ['q9', 'q10', 'q11', 'q14'];
        let profileValuesMatches = 0;
        profileValuesQuestions.forEach(q => {
            profileValuesMatches += calculateSimilarity(p1[q], p2[q]) / 100;
        });
        scores.profileValues = Math.round((profileValuesMatches / profileValuesQuestions.length) * 100);
        // Lifestyle Compatibility (q4=spontaneity, q5=personality, q6=career, q8=cuisine, q11=conflict)
        const profileLifestyleQuestions = ['q4', 'q5', 'q6', 'q8', 'q11'];
        let profileLifestyleMatches = 0;
        profileLifestyleQuestions.forEach(q => {
            profileLifestyleMatches += calculateSimilarity(p1[q], p2[q]) / 100;
        });
        scores.profileLifestyle = Math.round((profileLifestyleMatches / profileLifestyleQuestions.length) * 100);
        // Goals Alignment (q7=fitness, q12=vacation, q13=pet peeve, q16=success, q20=life motto)
        const profileGoalsQuestions = ['q7', 'q12', 'q13', 'q16', 'q20'];
        let profileGoalsMatches = 0;
        profileGoalsQuestions.forEach(q => {
            profileGoalsMatches += calculateSimilarity(p1[q], p2[q]) / 100;
        });
        scores.profileGoals = Math.round((profileGoalsMatches / profileGoalsQuestions.length) * 100);
        // Dealbreaker Check - Hard incompatibilities
        if (p1.q9 && p2.q9) {
            const q9_1 = normalizeAnswer(p1.q9);
            const q9_2 = normalizeAnswer(p2.q9);
            const wantsKids1 = q9_1.includes('yes') || q9_1.includes('want');
            const wantsKids2 = q9_2.includes('yes') || q9_2.includes('want');
            if (wantsKids1 !== wantsKids2) {
                scores.dealbreakers = 30;
            }
        }
        if (p1.q10 && p2.q10) {
            const q10_1 = normalizeAnswer(p1.q10);
            const q10_2 = normalizeAnswer(p2.q10);
            const isReligious1 = q10_1.includes('very') || q10_1.includes('important');
            const isReligious2 = q10_2.includes('very') || q10_2.includes('important');
            if (isReligious1 !== isReligious2) {
                scores.dealbreakers = Math.min(scores.dealbreakers, 40);
            }
        }
    }
    // ===== PERSONALITY QUESTIONNAIRE (10 questions) =====
    if (user1Data.personality && user2Data.personality && typeof user1Data.personality === 'object' && typeof user2Data.personality === 'object') {
        const pers1 = user1Data.personality;
        const pers2 = user2Data.personality;
        let personalityMatches = 0;
        let personalityCount = 0;
        for (let i = 1; i <= 10; i++) {
            const q = `id${i}`;
            if (pers1[q] && pers2[q]) {
                personalityMatches += calculateSimilarity(pers1[q], pers2[q]) / 100;
                personalityCount++;
            }
        }
        if (personalityCount > 0) {
            scores.personality = Math.round((personalityMatches / personalityCount) * 100);
            activeScores++;
        }
    }
    // ===== RELATIONSHIP GOALS QUESTIONNAIRE (8 questions) =====
    if (user1Data.relationshipGoals && user2Data.relationshipGoals && typeof user1Data.relationshipGoals === 'object' && typeof user2Data.relationshipGoals === 'object') {
        const rel1 = user1Data.relationshipGoals;
        const rel2 = user2Data.relationshipGoals;
        let relMatches = 0;
        let relCount = 0;
        for (let i = 1; i <= 8; i++) {
            const q = `id${i}`;
            if (rel1[q] && rel2[q]) {
                relMatches += calculateSimilarity(rel1[q], rel2[q]) / 100;
                relCount++;
            }
        }
        if (relCount > 0) {
            scores.relationshipGoals = Math.round((relMatches / relCount) * 100);
            activeScores++;
        }
    }
    // ===== LIFESTYLE QUESTIONNAIRE (10 questions) =====
    if (user1Data.lifestyle && user2Data.lifestyle && typeof user1Data.lifestyle === 'object' && typeof user2Data.lifestyle === 'object') {
        const life1 = user1Data.lifestyle;
        const life2 = user2Data.lifestyle;
        let lifeMatches = 0;
        let lifeCount = 0;
        for (let i = 1; i <= 10; i++) {
            const q = `id${i}`;
            if (life1[q] && life2[q]) {
                lifeMatches += calculateSimilarity(life1[q], life2[q]) / 100;
                lifeCount++;
            }
        }
        if (lifeCount > 0) {
            scores.lifestyle = Math.round((lifeMatches / lifeCount) * 100);
            activeScores++;
        }
    }
    // ===== VALUES & BELIEFS QUESTIONNAIRE (10 questions) =====
    if (user1Data.valuesBeliefs && user2Data.valuesBeliefs && typeof user1Data.valuesBeliefs === 'object' && typeof user2Data.valuesBeliefs === 'object') {
        const val1 = user1Data.valuesBeliefs;
        const val2 = user2Data.valuesBeliefs;
        let valMatches = 0;
        let valCount = 0;
        for (let i = 1; i <= 10; i++) {
            const q = `id${i}`;
            if (val1[q] && val2[q]) {
                valMatches += calculateSimilarity(val1[q], val2[q]) / 100;
                valCount++;
            }
        }
        if (valCount > 0) {
            scores.valuesBeliefs = Math.round((valMatches / valCount) * 100);
            activeScores++;
        }
    }
    // ===== INTERESTS & HOBBIES QUESTIONNAIRE (10 questions) =====
    if (user1Data.interestsHobbies && user2Data.interestsHobbies && typeof user1Data.interestsHobbies === 'object' && typeof user2Data.interestsHobbies === 'object') {
        const int1 = user1Data.interestsHobbies;
        const int2 = user2Data.interestsHobbies;
        let intMatches = 0;
        let intCount = 0;
        for (let i = 1; i <= 10; i++) {
            const q = `id${i}`;
            if (int1[q] && int2[q]) {
                intMatches += calculateSimilarity(int1[q], int2[q]) / 100;
                intCount++;
            }
        }
        if (intCount > 0) {
            scores.interestsHobbies = Math.round((intMatches / intCount) * 100);
            activeScores++;
        }
    }
    // ===== MUSIC PERSONALITY QUESTIONNAIRE (10 questions) =====
    if (user1Data.musicPersonality && user2Data.musicPersonality && typeof user1Data.musicPersonality === 'object' && typeof user2Data.musicPersonality === 'object') {
        const mus1 = user1Data.musicPersonality;
        const mus2 = user2Data.musicPersonality;
        let musMatches = 0;
        let musCount = 0;
        for (let i = 1; i <= 10; i++) {
            const q = `id${i}`;
            if (mus1[q] && mus2[q]) {
                musMatches += calculateSimilarity(mus1[q], mus2[q]) / 100;
                musCount++;
            }
        }
        if (musCount > 0) {
            scores.musicPersonality = Math.round((musMatches / musCount) * 100);
            activeScores++;
        }
    }
    // ===== LIFESTYLE PREFERENCES QUESTIONNAIRE (smoking, alcohol, drugs, tattoos, pets) =====
    if (user1Data.lifestylePreferences && user2Data.lifestylePreferences && typeof user1Data.lifestylePreferences === 'object' && typeof user2Data.lifestylePreferences === 'object') {
        const lp1 = user1Data.lifestylePreferences;
        const lp2 = user2Data.lifestylePreferences;
        let lpMatches = 0;
        const lpQuestions = ['smoking', 'alcohol', 'drugs', 'tattoos', 'pets'];
        let lpCount = 0;
        lpQuestions.forEach(q => {
            if (lp1[q] && lp2[q]) {
                lpMatches += calculateSimilarity(lp1[q], lp2[q]) / 100;
                lpCount++;
            }
        });
        if (lpCount > 0) {
            scores.lifestylePreferences = Math.round((lpMatches / lpCount) * 100);
            activeScores++;
        }
        // Dealbreaker checks for lifestyle preferences
        if (lp1.smoking && lp2.smoking) {
            const smoking1 = normalizeAnswer(lp1.smoking);
            const smoking2 = normalizeAnswer(lp2.smoking);
            const smokes1 = smoking1.includes('regularly') || smoking1.includes('yes');
            const smokes2 = smoking2.includes('regularly') || smoking2.includes('yes');
            if (smokes1 !== smokes2 && (smoking1.includes('never') || smoking2.includes('never'))) {
                scores.dealbreakers = Math.min(scores.dealbreakers, 50);
            }
        }
        if (lp1.alcohol && lp2.alcohol) {
            const alcohol1 = normalizeAnswer(lp1.alcohol);
            const alcohol2 = normalizeAnswer(lp2.alcohol);
            const heavy1 = alcohol1.includes('heavy');
            const heavy2 = alcohol2.includes('heavy');
            if (heavy1 !== heavy2 && (alcohol1.includes('never') || alcohol2.includes('never'))) {
                scores.dealbreakers = Math.min(scores.dealbreakers, 45);
            }
        }
        if (lp1.drugs && lp2.drugs) {
            const drugs1 = normalizeAnswer(lp1.drugs);
            const drugs2 = normalizeAnswer(lp2.drugs);
            const uses1 = drugs1.includes('regular') || drugs1.includes('occasional');
            const uses2 = drugs2.includes('regular') || drugs2.includes('occasional');
            if (uses1 !== uses2 && (drugs1.includes('never') || drugs2.includes('never'))) {
                scores.dealbreakers = Math.min(scores.dealbreakers, 40);
            }
        }
    }
    // Calculate weighted overall score - only use active scores
    let overallScore = 0;
    if (activeScores > 0) {
        // Calculate score using ONLY the weights for available data
        // Don't normalize - just use the actual weights
        const weightedSum = (scores.profileValues * 0.20) +
            (scores.profileGoals * 0.15) +
            (scores.profileLifestyle * 0.12) +
            (scores.relationshipGoals * 0.15) +
            (scores.valuesBeliefs * 0.12) +
            (scores.lifestyle * 0.10) +
            (scores.personality * 0.08) +
            (scores.lifestylePreferences * 0.05) +
            (scores.interestsHobbies * 0.02) +
            (scores.musicPersonality * 0.01);
        // The sum of all weights is 1.0, so we don't need to normalize
        overallScore = Math.round(weightedSum);
    }
    // Apply dealbreaker penalty - reduce score but don't multiply it to near zero
    const dealbreakerPenalty = Math.max(0, 100 - (100 - scores.dealbreakers) * 2);
    const finalScore = Math.round(overallScore * (dealbreakerPenalty / 100));
    // Generate summary
    let summary = '';
    if (finalScore >= 85) {
        summary = 'Excellent match! You share core values, goals, and lifestyle.';
    }
    else if (finalScore >= 75) {
        summary = 'Great match! Strong compatibility across multiple dimensions.';
    }
    else if (finalScore >= 65) {
        summary = 'Good match! Solid common ground on what matters.';
    }
    else if (finalScore >= 55) {
        summary = 'Decent match. Compatible in key areas with some differences.';
    }
    else if (finalScore >= 45) {
        summary = 'Moderate compatibility. Different priorities but potential.';
    }
    else if (finalScore >= 35) {
        summary = 'Limited compatibility. Significant differences to navigate.';
    }
    else {
        summary = 'Low compatibility. Very different values and goals.';
    }
    // Simplify breakdown for frontend display
    const simplifiedBreakdown = {
        profileValues: Math.round((scores.profileValues + scores.valuesBeliefs) / 2),
        profileLifestyle: Math.round((scores.profileLifestyle + scores.lifestyle) / 2),
        profileGoals: Math.round((scores.profileGoals + scores.relationshipGoals) / 2),
        dealbreakers: scores.dealbreakers
    };
    return {
        overallScore: finalScore,
        breakdown: simplifiedBreakdown,
        summary,
        sharedInterests: extractSharedInterests(user1Data.interestsHobbies, user2Data.interestsHobbies),
        sharedValues: extractSharedValues(user1Data.profile, user2Data.profile)
    };
};
// Get compatibility score with another user
router.get('/score/:targetUserId', authenticate, async (req, res) => {
    try {
        const userId = req.userId;
        const { targetUserId } = req.params;
        if (userId === targetUserId) {
            return res.status(400).json({ error: 'Cannot calculate compatibility with yourself' });
        }
        // Get current user
        const currentUser = await prisma.user.findUnique({
            where: { id: userId },
            select: { id: true, points: true, tier: true, trialTier: true, trialExpiresAt: true }
        });
        if (!currentUser) {
            return res.status(404).json({ error: 'User not found' });
        }
        // Check if user has premium access (Premium or VIP tier)
        const isPremium = currentUser.tier === 'premium' || currentUser.tier === 'vip';
        const isTrialPremium = currentUser.trialTier && (currentUser.trialTier === 'premium' || currentUser.trialTier === 'vip') && new Date(currentUser.trialExpiresAt) > new Date();
        // Check if user has enough coins (2 coins to view compatibility) - only for free users
        const COMPATIBILITY_COST = 2;
        if (!isPremium && !isTrialPremium && currentUser.points < COMPATIBILITY_COST) {
            return res.json({
                overallScore: null,
                breakdown: null,
                summary: 'Insufficient coins',
                locked: true,
                message: `Need ${COMPATIBILITY_COST} coins to view compatibility scores. You have ${currentUser.points} coins.`
            });
        }
        // Get both users' questionnaire data
        const [user1Q, user2Q, user1Pers, user2Pers, user1Rel, user2Rel, user1Life, user2Life, user1Val, user2Val, user1Int, user2Int, user1Mus, user2Mus, user1LP, user2LP] = await Promise.all([
            prisma.questionnaire.findUnique({ where: { userId } }),
            prisma.questionnaire.findUnique({ where: { userId: targetUserId } }),
            prisma.personalityQuestionnaire.findUnique({ where: { userId } }),
            prisma.personalityQuestionnaire.findUnique({ where: { userId: targetUserId } }),
            prisma.relationshipGoalsQuestionnaire.findUnique({ where: { userId } }),
            prisma.relationshipGoalsQuestionnaire.findUnique({ where: { userId: targetUserId } }),
            prisma.lifestyleQuestionnaire.findUnique({ where: { userId } }),
            prisma.lifestyleQuestionnaire.findUnique({ where: { userId: targetUserId } }),
            prisma.valuesBelifsQuestionnaire.findUnique({ where: { userId } }),
            prisma.valuesBelifsQuestionnaire.findUnique({ where: { userId: targetUserId } }),
            prisma.interestsHobbiesQuestionnaire.findUnique({ where: { userId } }),
            prisma.interestsHobbiesQuestionnaire.findUnique({ where: { userId: targetUserId } }),
            prisma.MusicPersonalityQuestionnaire.findUnique({ where: { userId } }),
            prisma.MusicPersonalityQuestionnaire.findUnique({ where: { userId: targetUserId } }),
            prisma.lifestylePreferencesQuestionnaire.findUnique({ where: { userId } }),
            prisma.lifestylePreferencesQuestionnaire.findUnique({ where: { userId: targetUserId } })
        ]);
        // Prepare user data object
        const user1Data = {
            profile: user1Q?.answers ? JSON.parse(user1Q.answers) : null,
            personality: user1Pers?.answers ? JSON.parse(user1Pers.answers) : null,
            relationshipGoals: user1Rel?.answers ? JSON.parse(user1Rel.answers) : null,
            lifestyle: user1Life?.answers ? JSON.parse(user1Life.answers) : null,
            valuesBeliefs: user1Val?.answers ? JSON.parse(user1Val.answers) : null,
            interestsHobbies: user1Int?.answers ? JSON.parse(user1Int.answers) : null,
            musicPersonality: user1Mus?.answers ? JSON.parse(user1Mus.answers) : null,
            lifestylePreferences: user1LP?.answers ? JSON.parse(user1LP.answers) : null
        };
        const user2Data = {
            profile: user2Q?.answers ? JSON.parse(user2Q.answers) : null,
            personality: user2Pers?.answers ? JSON.parse(user2Pers.answers) : null,
            relationshipGoals: user2Rel?.answers ? JSON.parse(user2Rel.answers) : null,
            lifestyle: user2Life?.answers ? JSON.parse(user2Life.answers) : null,
            valuesBeliefs: user2Val?.answers ? JSON.parse(user2Val.answers) : null,
            interestsHobbies: user2Int?.answers ? JSON.parse(user2Int.answers) : null,
            musicPersonality: user2Mus?.answers ? JSON.parse(user2Mus.answers) : null,
            lifestylePreferences: user2LP?.answers ? JSON.parse(user2LP.answers) : null
        };
        // Calculate compatibility
        const compatibility = calculateCompatibility(user1Data, user2Data);
        // Premium members can only see scores up to 40%
        // VIP members can see all scores
        if (isPremium && !isTrialPremium && currentUser.tier === 'premium') {
            if (compatibility.overallScore > 40) {
                // Hide the score for Premium users if it's above 40%
                return res.json({
                    overallScore: null,
                    breakdown: null,
                    summary: 'Upgrade to VIP to see this compatibility score',
                    locked: true,
                    message: 'This profile has high compatibility! Upgrade to VIP to see the full score.'
                });
            }
        }
        // Trial Premium members can only see scores up to 40%
        if (isTrialPremium && currentUser.trialTier === 'premium') {
            if (compatibility.overallScore > 40) {
                // Hide the score for trial Premium users if it's above 40%
                return res.json({
                    overallScore: null,
                    breakdown: null,
                    summary: 'Upgrade to VIP to see this compatibility score',
                    locked: true,
                    message: 'This profile has high compatibility! Upgrade to VIP to see the full score.'
                });
            }
        }
        // Deduct coins from user only if they're not premium
        if (!isPremium && !isTrialPremium) {
            await prisma.user.update({
                where: { id: userId },
                data: { points: { decrement: COMPATIBILITY_COST } }
            });
            // Record transaction
            await prisma.pointsTransaction.create({
                data: {
                    userId: userId,
                    amount: -COMPATIBILITY_COST,
                    type: 'compatibility_view',
                    reason: `Viewed compatibility score with user ${targetUserId}`
                }
            });
        }
        res.json(compatibility);
    }
    catch (err) {
        console.error('Error calculating compatibility:', err);
        res.status(500).json({ error: 'Failed to calculate compatibility' });
    }
});
export default router;
